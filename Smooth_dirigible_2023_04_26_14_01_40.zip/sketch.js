function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("#f733ff");
  text('hello', 10,90,);
  fill("#33f6ff");
  textSize(150);
  textFont("Blackjack");
  textStyle(ITALIC);
  stroke(30);
  strokeWeight(30);
 }

